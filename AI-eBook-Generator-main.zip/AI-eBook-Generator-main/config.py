# Replace with your Cohere API key from config
COHERE_API_KEY ="your-cohere-api-key"